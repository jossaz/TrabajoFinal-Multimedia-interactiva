Trabajo final multimedia interactiva
Integrantes
Jose Orlando Tovar Cano
Julian Camilo Ossa Zapata

Importante: En caso de error al abrir el código 
1. subir el volumen de el componente de la nave espacial, o el cuadrado en el pure data